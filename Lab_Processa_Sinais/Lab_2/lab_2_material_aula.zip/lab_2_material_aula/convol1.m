% convol1.m
% Fernando Passold, em 29/08/2023
% Exemplo simples de convolu��o discreta

% Sequ�ncias de entrada
% x = [1, 2, 3];
x = [1     1     2     1     1];
% h = [0.5, 1, 0.5];
h = [1     2     3     1     1];

% Comprimento das sequ�ncias
len_x = length(x);
len_h = length(h);

% Inicializa��o da sa�da da convolu��o
y = zeros(1, len_x + len_h - 1);

% C�lculo da convolu��o
for n = 1:length(y)
    for k = 1:len_h
        if n - k + 1 > 0 && n - k + 1 <= len_x
            y(n) = y(n) + x(n - k + 1) * h(k);
        end
    end
end

disp("Resultado da convolu��o y[n]:");
disp(y);

% plotando os resultados para melhor compreens�o
subplot(131); stem(x)
axis([0 6 0 5])
grid
title('x[k]')

subplot(132); stem(h)
axis([0 6 0 5])
grid
title('h[k]')

subplot(133); stem(y)
axis([0 6 0 5])
grid
title('y[k] = x[k] * h[k]')