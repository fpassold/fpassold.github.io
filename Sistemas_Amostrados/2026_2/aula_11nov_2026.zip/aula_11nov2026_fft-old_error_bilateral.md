# Obtendo Espectro de sinal usando *fft*

> Aula de 11/11/2026
> Assunto: Aprendendo a usar algoritmo *fft* para obter espectro de um sinal

Comandos com comentários realizados:

```matlab
>> diary "11nov2026.txt" % cria arquivo texto com cópia de comandos
>> f1=60;
>> f2=120;
>> f3=250;
>> fs=1000; % freq. de amostragem inicialmente usada
>> T=1/fs
T = 1.0000e-03
>> t=0:T:100*T;
>> size(t)
ans =
     1   101
>> y1=1.5*sin(2*pi*f1*t);
>> y2=0.8*sin(2*pi*f2*t);
>> y3=0.5*sin(2*pi*f3*t);
```

Poderiámos já fazer `y=y1+y2+y3` e plotar a forma de onda $(t,\ x)$. Mas antes mesmo de fazer isto, repara como ficou a amostragem do sinal mais rápido, de 250 Hz:

```matlab
>> plot(t,y3,'s-')
>> xlim([0 0.02])
>> grid
>> print("fig1.png", "-dpng", "-r150");  % salva figura com resolução melhor
>> % ![fig1.png](fig1.png) % comando para edição markdown
```

E temos a figura abaixo:

![fig1.png](fig1.png)

Notamos que amostramos poucos e apenas certos pontos da senóide da onda de 250 Hz, justamente os pontos nos quais a senóide passa por zero ou nos seus valores máximos e mínimos. O resultado (para um computador ou uP que vai trabalhar com estes dados, é que este sinal é onda triangular, não uma onda senoidal.

Temos que aumentar a quantidade de pontos amostrados na onda de 250 Hz, para melhorar esta impressão.

```matlab
>> fs=10*250;               % nova freq. de amostragem, 10 pontos por ciclo
>> fs
fs = 2500
>> T=1/fs                   % recalculando o novo incremento de tempo entre amostras
T = 4.0000e-04
>> t=0:T:100*T;             % recalculando vetor tempo
>> y3=0.5*sin(2*pi*f3*t);   % recalculando vetor y3
>> figure; plot(t,y3,'s-')
>> xlim([0 0.02])
>> grid
>> print("fig2.png", "-dpng", "-r150");  % salva figura com resolução melhor
```

Figura resultante:

![ig2.png](fig2.png)

Notamos que esta quantidade de amostras permite distinguir visualmente entre onda triangular e senoidal. Mas poderíamos aumentar ainda mais a freq. de amostragem usada, ou quantidade de pontos por amostra.

```matlab
>> % Vamos subir para 20 pts/ciclo em 250Hz
>> fs=20*250 % freq. de amostragem
fs = 5000
>> T=1/fs
T = 2.0000e-04
>> t=0:T:100*T;     % continuamos amostrando 100 amostras
>> size(t)
ans =
     1   101
>> y3=0.5*sin(2*pi*f3*t);
>> figure; plot(t,y3,'ms-')
>> grid
>> print("fig3.png", "-dpng", "-r150");  % salva figura com resolução melhor
```

A onda de 250 Hz, amostrada numa frequênica 20 vezes maior (20 pontos por ciclo), rende a figura abaixo:

![fig3.png](fig3.png)

Sintetizando as outras ondas e compondo o sinal final:

```matlab
>> y1=1.5*sin(2*pi*f1*t);
>> y2=0.8*sin(2*pi*f2*t);
>> y=y1+y2+y3; % compondo o sinal
>> figure; plot(t,y)
>> grid
>> print("y_100pts.png", "-dpng", "-r150");
```

Obtemos o seguinte resultado:

![y_100pts](y_100pts.png)

A principio, este sinal parece incorrento. Não conseguimos detectar um "padrão", ou perceber que o mesmo é periódico. Revisando os comandos, percebemos que não fizemos nada errado. O problema está na quantidade de amostras; 100 amostras é insuficiente para que se possa perceber alguma periodicidade do sinal $y(t)$. Necessitamos incrementar o número de amostras. Decidimos por subir de 100 para 500 amostras.

```matlab
>> % 100 amostras é pouco
>> t=0:T:500*T;
>> y1=1.5*sin(2*pi*60*t);
>> y2=0.8*sin(2*pi*120*t);
>> y3=0.5*sin(2*pi*250*t);
>> y=y1+y2+y3; % compondo o sinal
>> figure; plot(t,y)
>> print("y_500pts.png", "-dpng", "-r150");  % salva figura com resolução melhor
```

Sinal $y(t)$, sintetizado usando $f_s=$ 5 KHz, 500 amostras:

![y_500pts.png](y_500pts.png)

A ideia agora (era o objetivo inicial) é usar o algoritmo *fft* sobre o sinal $y(t)$ e confirmar se conseguimos (ou não), recuperar/enteder os componentes originais da onda.

```matlab
>> % rodando a fft
>> Y=fft(y);
>> size(y)          % note y = y(t), no domínio tempo
ans =
     1   501
>> size(Y)          % note: Y = Y(w) = F{y(t)}, estamos no domínio frequencia
ans =
     1   501
>> Y(1:5)'          %  mostra primeiros 5 valores (note n[umeros complexos)
ans =
   0.0000 -      0i
   0.0022 + 0.3432i
   0.0092 + 0.7372i
   0.0239 + 1.2688i
   0.0544 + 2.1693i

>> Ymag=abs(Y);     % obtendo o módulo/magnitudo do vetor
>> N=length(Ymag)   % confirmando qtdade de pontos = qtdade do sinal de entrada
N = 501
```

Note: o algoritmo *fft* não devolve o eixo X associado com frequência. É você, o usuário do algoritmo que deve saber como sintetizar este vetor.

```matlab
>> f=(0:N-1)*fs/N;      % montando o vetor das frequênicas (bins)
>> [f(1:5)' Ymag(1:5)'] % monstrando primeiros 5 valores de freq x |Y(w)|
ans =
         0    0.0000
    9.9800    0.3432
   19.9601    0.7373
   29.9401    1.2690
   39.9202    2.1700
```

Cada amostra (novo valor, cada componente) do vetor $Y(\Omega)$ gerado usando algoritmo *fft* está associado com um *bin* de frequência. O intervalo frequencial entre cada elemento de $Y(\Omega)$ depende da quantidade de pontos do vetor de entrada $y(t)$, e funciona assim: 

$\Delta_f (bin)=\dfrac{f_s}{N} \qquad$ (1)

onde: $f_s=$ período de amostragem do sinal $y(t)$ passado como vetor de entrada; $N=$ número de pontos/amostras passadas.

Então podemos calcular o que chamamos de "Resolução frequencial" (eq. (1)), neste caso:

```matlab
>> (5000)/501
ans = 9.9800
```

Note que não é valor *inteiro*. Se tivéssemos tomado o cuidado de limitar o vetor $y(y)$ à 500 pontos, teríamos obtido uma resolução espectral mais conveniente para o nosso caso:

$\Delta_f (bin)=\dfrac{5000}{500}=10$ (Hz)

Mas, vamos continuar assim mesmo...

```matlab
>> figure; stem(f,Ymag)
>> grid
>> print("fft_inicial.png", "-dpng", "-r150");
```

Confirmando a resolução frequencial:

```matlab
>> f(1)
ans = 0
>> f(2)
ans = 9.9800
```

O gráfico inicial ficou:

![fft_inicial.png](fft_inicial.png)

E então percebemos que o algoritmo *fft* calcula a transformada de Fourier bilateralmente no espectro. Notar que a maior frequência calculada corresponde à frequência de Nyquist, que é:

$f_{Nyquist}=\dfrac{f_s}{2}=\dfrac{5000}{2}=$ 2500 Hz.

Note que o algorimto *fft* originalmente calcula a transformada bilateral de Fourier. A página [Angle](https://www.mathworks.com/help/matlab/ref/angle.html) da Mathwork/Matlab até sugere uma forma de plotar este gráfico de outra forma para ficar mais clara o detalhe do espectro bilateral:

```matlab
>> size(Ymag)
ans =
     1   501
>> N/2
ans = 250.50
>> fix(N/2) % retornar valor inteiro
ans = 250
>> freq=(fix(-N/2):fix(N/2))/N*fs;
>> size(freq)
ans =
     1   501
>> figure; stem(freq,Ymag);
>> print("fft_inicial_bilateral.png", "-dpng", "-r150");
>> xlabel('Frequencia (Hz)')
>> ylabel('|Y(\omega)|')
>> title('FFT bilateral')
``` 

E temos então o gráfico:

![fft_inicial_bilateral.png](fft_inicial_bilateral.png)

Mas limitando o gráfico para a região unilateral, lado esquerdo:

```matlab
>> xlim([0 5000/2])
>> print("fft_unilateral.png", "-dpng", "-r150");  % salva figura com resolução melhor
```

E transformamos o gráfico original de $|Y(\Omega)|$, num gráfico unilateral:

![ft_unilateral.png](ft_unilateral.png)



Agora vamos analizar mais este gráfico e entender melhor o que fez o algoritmo *fft*.


>> Ymag=Ymag/N; % re-escalone amplitudes
>> Ymag(2:end-1)=2*Ymag(2:end-1);
>> N/2
ans = 250.50
>> f(250)
ans = 2485.0
>> f(251)
ans = 2495.0
>> f(252)
ans = 2505.0
>> figure; stem(f(1:251),Ymag(1:251))
>> grid
>> 250/9.98
ans = 25.050
>> f(25)
ans = 239.52
>> f(26)
ans = 249.50
>> f(27)
ans = 259.48
>> 120/9.98
ans = 12.024
>> f(12)
ans = 109.78
>> f(13)
ans = 119.76
>> f(14)
ans = 129.74
>> 60/9.98
ans = 6.0120
>> f(6)
ans = 49.900
>> f(7)
ans = 59.880
>> f(8)
ans = 69.860
>> 
>> aux=[7 8 13 14 26 27];
>> [f(aux)' Ymag(aux)']
ans =

   5.9880e+01   1.5008e+00
   6.9860e+01   1.6191e-02
   1.1976e+02   7.9567e-01
   1.2974e+02   2.2541e-02
   2.4950e+02   4.9390e-01
   2.5948e+02   3.0056e-02

>> format shortg
>> [f(aux)' Ymag(aux)']
ans =

        59.88       1.5008
        69.86     0.016191
       119.76      0.79567
       129.74     0.022541
        249.5       0.4939
       259.48     0.030056

>> Yfase=angle(Y);
>> Yfase=rad2deg(Yfase);
>> Yfase=Yfase/90; % compensar o bilateral
>> figure; stem(f(1:251),Yfase(1:251))
>> figure(4)
>> print("espectro_fase.png", "-dpng", "-r150");  % salva figura com resolução melhor
>> figure(3)
>> print("espectro_magnitude.png", "-dpng", "-r150");  % salva figura com resolução melhor
>> 
>> % Mostrar uma tabela valores relevantes
>> [f(aux)' Ymag(aux)' Yfase(aux)']
ans =

        59.88       1.5008     -0.97605
        69.86     0.016191       1.0279
       119.76      0.79567      -0.9521
       129.74     0.022541       1.0519
        249.5       0.4939      -0.9002
       259.48     0.030056       1.1038

>> save aula_11nov2026
>> diary off
